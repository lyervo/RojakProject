<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function showuser()
{
    global $db;
    $query = " SELECT user.user_id,user.username,recipe.recipe_id,recipe.recipe_name,recipe.difficulty,recipe.cooking_time,recipe.image_blob,recipe.description,recipe.serving,recipe.author FROM recipe
    INNER JOIN user ON user.user_id = recipe.author LIMIT 3";
    $statement = $db->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll();
    $statement->closeCursor();
    return $result;
}