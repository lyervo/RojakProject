<?php
$current = 'home';
include 'header.php';
require '../model/recipe_db.php';

$user = showuser();
?>


  
<!-- Page Content -->
<div class="container">

    <div class="row">

        <!--        side div-->
        <div class="col-lg-1">

            <input type="text" id="term" placeholder="Search..."><button id="search_icon" onclick="searchRecipe()"><i class="fas fa-search"></i></button><br>

            <p>Must have:</p>
            <input type="checkbox" value="vegan" class="tag">Vegan<br>
            <input type="checkbox" value="halal" class="tag">Halal<br>
            <input type="checkbox" value="kosher" class="tag">Kosher<br>


            <p>Exclude:</p>
            <input type="checkbox" value="no_wheat" class="noTag">Wheat<br>
            <input type="checkbox" value="no_crustacean" class="noTag">Crustaceans<br>
            <input type="checkbox" value="no_egg" class="noTag">Egg<br>
            <input type="checkbox" value="no_fish" class="noTag">Fish<br>
            <input type="checkbox" value="no_peanut" class="noTag">Peanuts<br>
            <input type="checkbox" value="no_soy" class="noTag">Soy<br>
            <input type="checkbox" value="no_milk" class="noTag">Milk<br>
            <input type="checkbox" value="no_nuts" class="noTag">Nuts<br>
            <input type="checkbox" value="no_celery" class="noTag">Celery<br>
            <input type="checkbox" value="no_mustard" class="noTag">Mustard<br>
            <input type="checkbox" value="no_sesame" class="noTag">Sesame<br>
            <input type="checkbox" value="no_shellfish" class="noTag">Shellfish<br>

            Sort by 
            <select id="sort">
                <option value="recipe_name">Name</option>
                <option value="time">Submitted Date</option>
                <option value="rating">User Rating</option>
                <option value="cooking_time">Cooking Time</option>

            </select>
            <select id="order">
                <option value="asc">Ascending Order</option>
                <option value="desc">Descending Order</option>
            </select>

            
             <!-- Button trigger modal -->
             
             
        
        
        

        
        </div>
        <!-- /.col-lg-3 -->

        <!--        body div-->

       
        <div class="col-lg-10">
 <div class="center_content">


        <div class="center_title_bar">Popular Recipes</div>
        <?php
        $response = '';

        foreach ($user as $v) {
            ?>

            <div class="div2">


                <div class="card">


                    <?php echo '<img src="data:image/jpeg;base64,' . base64_encode($v['image_blob']) . '" height="200px" width="200px"/>'; ?>
                    <div class="name"> <h2><?php echo $v['recipe_name'] ?></h2></div>
                    <div class="prod_details_tab">
                        <?php
                        $dif = $v['difficulty'];
                        $easy = 'Easy';
                        $medium = 'Medium';
                        $hard = 'Hard';

                        if ($v['difficulty'] == $easy) {
                            ?>
                            <a href="http://all-free-download.com/free-website-templates/" title="header=[Easy] body=[This dish is a begginer friendly] fade=[on]">
                                <i class="fas fa-utensils"></i></a>     
                        <?php
                        }
                        if ($v['difficulty'] == $hard) {
                            ?>
                        
                            <a href="http://all-free-download.com/free-website-templates/" title="header=[Difficulty] body=[This is how hard a dish might be] fade=[on]">
                                <i id="icon1Hard" class="fas fa-utensils"></i></a> 
                            <a href="http://all-free-download.com/free-website-templates/" title="header=[Difficulty] body=[This is how hard a dish might be] fade=[on]">
                                <i id="icon2Hard" class="fas fa-utensils"></i></a> 
                            <a href="http://all-free-download.com/free-website-templates/" title="header=[Difficulty] body=[This is how hard a dish might be] fade=[on]">
                                <i id="icon3Hard" class="fas fa-utensils"></i></a>
                        <?php
                        }
                        if ($v['difficulty'] == $medium) {
                            ?>
                            <a href="http://all-free-download.com/free-website-templates/" title="header=[Difficulty] body=[This is how hard a dish might be] fade=[on]">
                                <i id="icon1Med" class="fas fa-utensils"></i></a> 
                            <a href="http://all-free-download.com/free-website-templates/" title="header=[Difficulty] body=[This is how hard a dish might be] fade=[on]">
                                <i id="icon2Med" class="fas fa-utensils"></i></a> 
    <?php } ?>

                    </div>
                    <p class="price"></a>By:<?php echo $v['username'] ?></p>
                    <p class="price"></a>Servings: <?php echo $v['serving'] ?></p>
                    <p class="price"></a>Cooking Time: <?php echo $v['cooking_time'] ?></p>

                    <div class="fade"><p><?php echo $v['description'] ?></p></div>
                    <p><button>View</button></p>

                </div>

            </div>
            <?php
        }
        ?>  
  </div>
            <div id="result"></div>




        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /.container -->
    


</body>

</html>
